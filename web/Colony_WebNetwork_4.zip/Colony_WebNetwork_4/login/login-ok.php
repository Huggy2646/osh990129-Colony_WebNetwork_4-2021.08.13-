<!doctype html>
<html lang="ko">
	<head>
		<meta charset="utf-8">
		<title>로그인 성공!</title>
		<style>
			body { font-family: sans-serif; font-size: 14px; }
			input, button { font-family: inherit; font-size: inherit; }
		</style>
	</head>
	<body>
		<h1>로그인 하셨습니다.</h1>
		<p><input type="button" value="Go to gambling" onCLICK="location.href='fix.php'"></p>
	</body>
</html>