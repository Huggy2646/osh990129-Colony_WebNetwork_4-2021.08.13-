service apache2 stop
service mysql stop
