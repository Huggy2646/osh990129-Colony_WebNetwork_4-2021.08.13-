<?php
	$co_conn = mysqli_connect( 'localhost', 'root', 'welcome_to_here', 'colony' );
	if(!isset($_COOKIE["uid"])) {
		print("[DEBUG] NO COOKIE");
	} else {
		print("[DEBUG] YES COOKIE!");
	}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
      <p style="text-align:right;"><h2>
        <?php
          $point=100;
          $loss_point=0;
          echo "point:".$point;
        ?>
      </h2>
      </p>

      <?php
      $image = array("ladder.png","ladder2.png","ladder3.png");  // 이미지 파일명을 갯수만큼 배열로 적음
      $random = time()%count($image);
      ?>

	
      <?php
        if (($_GET['id'] === "0" and $random==1))
        {
          echo "<script>alert(\"축하합니다.\");</script>";
        }
        elseif (($_GET['id'] === "1" and $random==2))
        {
          echo "<script>alert(\"축하합니다.\");</script>";
        }
        elseif ($_GET['id'] === "0" and $random==3)
        {
          echo "<script>alert(\"축하합니다.\");</script>";
        }
        else
        {
          echo "<script>alert(\"포인트 77ㅓ억~\");</script>";
        }
      ?>
	<center><img src="<?=$image[$random]?>" width="50%"></center>
	<center><a href="colony2.php">다시하기</a></center>







  </body>
</html>
