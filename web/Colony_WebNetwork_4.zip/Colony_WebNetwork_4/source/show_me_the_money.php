<?php
		$co_conn = mysqli_connect( 'localhost', 'root', 'welcome_to_here', 'colony' );
	if(!isset($_COOKIE["uid"])) {
		header( 'Location: login.php' );
	} else {
		$uid = explode(" ", $_COOKIE["uid"]);
		$id = $uid[0];
		$pw = $uid[1];
		$co_sql = "SELECT money FROM user WHERE id = '" . $id . "';";
		$co_result = mysqli_query( $co_conn, $co_sql );
		while ( $co_row = mysqli_fetch_array( $co_result ) ) {
			$money = $co_row[ 'money' ];
		}
		# id, pw, money
	}
	/*
	$co_sql = "UPDATE user SET money='".$money."' WHERE id='".$id."';";
	mysqli_query( $co_conn, $co_sql );
	*/
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
	  <p> 아직 구현중입니다....</p>
  </body>
</html>