<!doctype html>
<html>
<head>
	<title>Do you want money?</title>
</head>
<body>
	<h2> <center>Money copy bug world</center> </h2>
	
	<center> <img src="gambling.jpg" width="300"> </center>
  <center><a href="colony2.php"><img src="2543050.jpg" width="10%"> </center>
</body>
</html>
