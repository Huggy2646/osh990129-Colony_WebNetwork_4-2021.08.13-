<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
      <p style="text-align:right;"><h2>
        <?php
          $point=100;
          $loss_point=0;
          echo "point:".$point;
        ?>
      </h2>
      </p>

      <?php
      $image = array("hide_ladder.png");  // 이미지 파일명을 갯수만큼 배열로 적음
      $random = time()%count($image);
      ?>
	<center><p><img src="<?=$image[$random]?>" width="50%"></p></center>
	<center><a href="colony3.php?id=0">홀</a> <a href="colony3.php?id=1">짝</a></center>

  </body>
</html>
