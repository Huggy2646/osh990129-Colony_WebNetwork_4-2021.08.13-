<?php
	$jb_conn = mysqli_connect( 'localhost', 'root', 'welcome_to_here', 'colony' );

    $cookieName = "uid";
    $cookieValue = "123";
    setcookie($cookieName, $cookieValue, time()+60, "/"); // 쿠키가 60초 간 지속됨.
?>

...

<?php

    if(!isset($_COOKIE[$cookieName])) { // 해당 쿠키가 존재하지 않을 때

        echo "{$cookieName}라는 이름의 쿠키는 아직 생성되지 않았습니다.";

    } else {                            // 해당 쿠키가 존재할 때

        echo "{$cookieName}라는 이름의 쿠키가 생성되었으며, 생성된 값은 '".$_COOKIE[$cookieName]."'입니다.";

    }

?>

<!doctype html>
<html>
<head>
	<title>Do you want money?</title>
</head>
<body>
	<h2> <center>Money copy bug world</center> </h2>
	<center> <img src="gambling.jpg" width="300"> </center>
  <center><a href="colony2.php"><img src="2543050.jpg" width="10%"> </center>
</body>
</html>
