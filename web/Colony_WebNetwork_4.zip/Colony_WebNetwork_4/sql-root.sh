mysql -u root -p
